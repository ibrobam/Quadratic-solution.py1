# Quadratic-solution.py1
Quadratic solution.py1
